module.exports = {
  prefixes: ["+"],
  ownerIds: ["206161807491072000"],
};
